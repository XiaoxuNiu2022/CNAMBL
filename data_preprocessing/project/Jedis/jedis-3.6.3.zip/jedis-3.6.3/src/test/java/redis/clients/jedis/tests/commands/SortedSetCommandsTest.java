package redis.clients.jedis.tests.commands;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;
import static redis.clients.jedis.ScanParams.SCAN_POINTER_START;
import static redis.clients.jedis.ScanParams.SCAN_POINTER_START_BINARY;
import static redis.clients.jedis.tests.utils.AssertUtil.assertByteArraySetEquals;
import static redis.clients.jedis.tests.utils.AssertUtil.assertCollectionContains;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import redis.clients.jedis.BuilderFactory;
import redis.clients.jedis.ScanParams;
import redis.clients.jedis.ScanResult;
import redis.clients.jedis.Tuple;
import redis.clients.jedis.ZParams;
import redis.clients.jedis.params.ZAddParams;
import redis.clients.jedis.params.ZIncrByParams;
import redis.clients.jedis.resps.KeyedZSetElement;
import redis.clients.jedis.util.SafeEncoder;

public class SortedSetCommandsTest extends JedisCommandTestBase {
  final byte[] bfoo = { 0x01, 0x02, 0x03, 0x04 };
  final byte[] bbar = { 0x05, 0x06, 0x07, 0x08 };
  final byte[] bcar = { 0x09, 0x0A, 0x0B, 0x0C };
  final byte[] ba = { 0x0A };
  final byte[] bb = { 0x0B };
  final byte[] bc = { 0x0C };
  final byte[] bInclusiveB = { 0x5B, 0x0B };
  final byte[] bExclusiveC = { 0x28, 0x0C };
  final byte[] bLexMinusInf = { 0x2D };
  final byte[] bLexPlusInf = { 0x2B };

  final byte[] bbar1 = { 0x05, 0x06, 0x07, 0x08, 0x0A };
  final byte[] bbar2 = { 0x05, 0x06, 0x07, 0x08, 0x0B };
  final byte[] bbar3 = { 0x05, 0x06, 0x07, 0x08, 0x0C };
  final byte[] bbarstar = { 0x05, 0x06, 0x07, 0x08, '*' };

  @Test
  public void zadd() {
    long status = jedis.zadd("foo", 1d, "a");
    assertEquals(1, status);

    status = jedis.zadd("foo", 10d, "b");
    assertEquals(1, status);

    status = jedis.zadd("foo", 0.1d, "c");
    assertEquals(1, status);

    status = jedis.zadd("foo", 2d, "a");
    assertEquals(0, status);

    // Binary
    long bstatus = jedis.zadd(bfoo, 1d, ba);
    assertEquals(1, bstatus);

    bstatus = jedis.zadd(bfoo, 10d, bb);
    assertEquals(1, bstatus);

    bstatus = jedis.zadd(bfoo, 0.1d, bc);
    assertEquals(1, bstatus);

    bstatus = jedis.zadd(bfoo, 2d, ba);
    assertEquals(0, bstatus);

  }

  @Test
  public void zaddWithParams() {
    jedis.del("foo");

    // xx: never add new member
    long status = jedis.zadd("foo", 1d, "a", ZAddParams.zAddParams().xx());
    assertEquals(0L, status);

    jedis.zadd("foo", 1d, "a");
    // nx: never update current member
    status = jedis.zadd("foo", 2d, "a", ZAddParams.zAddParams().nx());
    assertEquals(0L, status);
    assertEquals(Double.valueOf(1d), jedis.zscore("foo", "a"));

    Map<String, Double> scoreMembers = new HashMap<String, Double>();
    scoreMembers.put("a", 2d);
    scoreMembers.put("b", 1d);
    // ch: return count of members not only added, but also updated
    status = jedis.zadd("foo", scoreMembers, ZAddParams.zAddParams().ch());
    assertEquals(2L, status);

    // lt: only update existing elements if the new score is less than the current score.
    jedis.zadd("foo", 3d, "a", ZAddParams.zAddParams().lt());
    assertEquals(Double.valueOf(2d), jedis.zscore("foo", "a"));
    jedis.zadd("foo", 1d, "a", ZAddParams.zAddParams().lt());
    assertEquals(Double.valueOf(1d), jedis.zscore("foo", "a"));

    // gt: only update existing elements if the new score is greater than the current score.
    jedis.zadd("foo", 0d, "b", ZAddParams.zAddParams().gt());
    assertEquals(Double.valueOf(1d), jedis.zscore("foo", "b"));
    jedis.zadd("foo", 2d, "b", ZAddParams.zAddParams().gt());
    assertEquals(Double.valueOf(2d), jedis.zscore("foo", "b"));

    // incr: don't update already existing elements.
    assertNull(jedis.zaddIncr("foo", 1d, "b", ZAddParams.zAddParams().nx()));
    assertEquals(Double.valueOf(2d), jedis.zscore("foo", "b"));
    // incr: update elements that already exist.
    assertEquals(Double.valueOf(3d), jedis.zaddIncr("foo", 1d,"b", ZAddParams.zAddParams().xx()));
    assertEquals(Double.valueOf(3d), jedis.zscore("foo", "b"));

    // binary
    jedis.del(bfoo);

    // xx: never add new member
    status = jedis.zadd(bfoo, 1d, ba, ZAddParams.zAddParams().xx());
    assertEquals(0L, status);

    jedis.zadd(bfoo, 1d, ba);
    // nx: never update current member
    status = jedis.zadd(bfoo, 2d, ba, ZAddParams.zAddParams().nx());
    assertEquals(0L, status);
    assertEquals(Double.valueOf(1d), jedis.zscore(bfoo, ba));

    Map<byte[], Double> binaryScoreMembers = new HashMap<byte[], Double>();
    binaryScoreMembers.put(ba, 2d);
    binaryScoreMembers.put(bb, 1d);
    // ch: return count of members not only added, but also updated
    status = jedis.zadd(bfoo, binaryScoreMembers, ZAddParams.zAddParams().ch());
    assertEquals(2L, status);

    // lt: only update existing elements if the new score is less than the current score.
    jedis.zadd(bfoo, 3d, ba, ZAddParams.zAddParams().lt());
    assertEquals(Double.valueOf(2d), jedis.zscore(bfoo, ba));
    jedis.zadd(bfoo, 1d, ba, ZAddParams.zAddParams().lt());
    assertEquals(Double.valueOf(1d), jedis.zscore(bfoo, ba));

    // gt: only update existing elements if the new score is greater than the current score.
    jedis.zadd(bfoo, 0d, bb, ZAddParams.zAddParams().gt());
    assertEquals(Double.valueOf(1d), jedis.zscore(bfoo, bb));
    jedis.zadd(bfoo, 2d, bb, ZAddParams.zAddParams().gt());
    assertEquals(Double.valueOf(2d), jedis.zscore(bfoo, bb));

    // incr: don't update already existing elements.
    assertNull(jedis.zaddIncr(bfoo, 1d, bb, ZAddParams.zAddParams().nx()));
    assertEquals(Double.valueOf(2d), jedis.zscore(bfoo, bb));
    // incr: update elements that already exist.
    assertEquals(Double.valueOf(3d), jedis.zaddIncr(bfoo, 1d, bb, ZAddParams.zAddParams().xx()));
    assertEquals(Double.valueOf(3d), jedis.zscore(bfoo, bb));
  }

  @Test
  public void zrange() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("c");
    expected.add("a");

    Set<String> range = jedis.zrange("foo", 0, 1);
    assertEquals(expected, range);

    expected.add("b");
    range = jedis.zrange("foo", 0, 100);
    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bc);
    bexpected.add(ba);

    Set<byte[]> brange = jedis.zrange(bfoo, 0, 1);
    assertByteArraySetEquals(bexpected, brange);

    bexpected.add(bb);
    brange = jedis.zrange(bfoo, 0, 100);
    assertByteArraySetEquals(bexpected, brange);

  }

  @Test
  public void zrangeByLex() {
    jedis.zadd("foo", 1, "aa");
    jedis.zadd("foo", 1, "c");
    jedis.zadd("foo", 1, "bb");
    jedis.zadd("foo", 1, "d");

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("bb");
    expected.add("c");

    // exclusive aa ~ inclusive c
    assertEquals(expected, jedis.zrangeByLex("foo", "(aa", "[c"));

    expected.clear();
    expected.add("bb");
    expected.add("c");

    // with LIMIT
    assertEquals(expected, jedis.zrangeByLex("foo", "-", "+", 1, 2));
  }

  @Test
  public void zrangeByLexBinary() {
    // binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 1, bc);
    jedis.zadd(bfoo, 1, bb);

    Set<byte[]> bExpected = new LinkedHashSet<byte[]>();
    bExpected.add(bb);

    assertByteArraySetEquals(bExpected, jedis.zrangeByLex(bfoo, bInclusiveB, bExclusiveC));

    bExpected.clear();
    bExpected.add(ba);
    bExpected.add(bb);

    // with LIMIT
    assertByteArraySetEquals(bExpected, jedis.zrangeByLex(bfoo, bLexMinusInf, bLexPlusInf, 0, 2));
  }

  @Test
  public void zrevrangeByLex() {
    jedis.zadd("foo", 1, "aa");
    jedis.zadd("foo", 1, "c");
    jedis.zadd("foo", 1, "bb");
    jedis.zadd("foo", 1, "d");

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("c");
    expected.add("bb");

    // exclusive aa ~ inclusive c
    assertEquals(expected, jedis.zrevrangeByLex("foo", "[c", "(aa"));

    expected.clear();
    expected.add("c");
    expected.add("bb");

    // with LIMIT
    assertEquals(expected, jedis.zrevrangeByLex("foo", "+", "-", 1, 2));
  }

  @Test
  public void zrevrangeByLexBinary() {
    // binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 1, bc);
    jedis.zadd(bfoo, 1, bb);

    Set<byte[]> bExpected = new LinkedHashSet<byte[]>();
    bExpected.add(bb);

    assertByteArraySetEquals(bExpected, jedis.zrevrangeByLex(bfoo, bExclusiveC, bInclusiveB));

    bExpected.clear();
    bExpected.add(bb);
    bExpected.add(ba);

    // with LIMIT
    assertByteArraySetEquals(bExpected, jedis.zrevrangeByLex(bfoo, bLexPlusInf, bLexMinusInf, 0, 2));
  }

  @Test
  public void zrevrange() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("b");
    expected.add("a");

    Set<String> range = jedis.zrevrange("foo", 0, 1);
    assertEquals(expected, range);

    expected.add("c");
    range = jedis.zrevrange("foo", 0, 100);
    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bb);
    bexpected.add(ba);

    Set<byte[]> brange = jedis.zrevrange(bfoo, 0, 1);
    assertByteArraySetEquals(bexpected, brange);

    bexpected.add(bc);
    brange = jedis.zrevrange(bfoo, 0, 100);
    assertByteArraySetEquals(bexpected, brange);

  }

  @Test
  public void zrem() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 2d, "b");

    long status = jedis.zrem("foo", "a");

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("b");

    assertEquals(1, status);
    assertEquals(expected, jedis.zrange("foo", 0, 100));

    status = jedis.zrem("foo", "bar");

    assertEquals(0, status);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 2d, bb);

    long bstatus = jedis.zrem(bfoo, ba);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bb);

    assertEquals(1, bstatus);
    assertByteArraySetEquals(bexpected, jedis.zrange(bfoo, 0, 100));

    bstatus = jedis.zrem(bfoo, bbar);

    assertEquals(0, bstatus);

  }

  @Test
  public void zincrby() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 2d, "b");

    double score = jedis.zincrby("foo", 2d, "a");

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("a");
    expected.add("b");

    assertEquals(3d, score, 0);
    assertEquals(expected, jedis.zrange("foo", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 2d, bb);

    double bscore = jedis.zincrby(bfoo, 2d, ba);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bb);
    bexpected.add(ba);

    assertEquals(3d, bscore, 0);
    assertByteArraySetEquals(bexpected, jedis.zrange(bfoo, 0, 100));

  }

  @Test
  public void zincrbyWithParams() {
    jedis.del("foo");

    // xx: never add new member
    Double score = jedis.zincrby("foo", 2d, "a", ZIncrByParams.zIncrByParams().xx());
    assertNull(score);

    jedis.zadd("foo", 2d, "a");

    // nx: never update current member
    score = jedis.zincrby("foo", 1d, "a", ZIncrByParams.zIncrByParams().nx());
    assertNull(score);
    assertEquals(Double.valueOf(2d), jedis.zscore("foo", "a"));

    // Binary

    jedis.del(bfoo);

    // xx: never add new member
    score = jedis.zincrby(bfoo, 2d, ba, ZIncrByParams.zIncrByParams().xx());
    assertNull(score);

    jedis.zadd(bfoo, 2d, ba);

    // nx: never update current member
    score = jedis.zincrby(bfoo, 1d, ba, ZIncrByParams.zIncrByParams().nx());
    assertNull(score);
    assertEquals(Double.valueOf(2d), jedis.zscore(bfoo, ba));
  }

  @Test
  public void zrank() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 2d, "b");

    long rank = jedis.zrank("foo", "a");
    assertEquals(0, rank);

    rank = jedis.zrank("foo", "b");
    assertEquals(1, rank);

    assertNull(jedis.zrank("car", "b"));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 2d, bb);

    long brank = jedis.zrank(bfoo, ba);
    assertEquals(0, brank);

    brank = jedis.zrank(bfoo, bb);
    assertEquals(1, brank);

    assertNull(jedis.zrank(bcar, bb));

  }

  @Test
  public void zrevrank() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 2d, "b");

    long rank = jedis.zrevrank("foo", "a");
    assertEquals(1, rank);

    rank = jedis.zrevrank("foo", "b");
    assertEquals(0, rank);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 2d, bb);

    long brank = jedis.zrevrank(bfoo, ba);
    assertEquals(1, brank);

    brank = jedis.zrevrank(bfoo, bb);
    assertEquals(0, brank);

  }

  @Test
  public void zrangeWithScores() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("c", 0.1d));
    expected.add(new Tuple("a", 2d));

    Set<Tuple> range = jedis.zrangeWithScores("foo", 0, 1);
    assertEquals(expected, range);

    expected.add(new Tuple("b", 10d));
    range = jedis.zrangeWithScores("foo", 0, 100);
    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bc, 0.1d));
    bexpected.add(new Tuple(ba, 2d));

    Set<Tuple> brange = jedis.zrangeWithScores(bfoo, 0, 1);
    assertEquals(bexpected, brange);

    bexpected.add(new Tuple(bb, 10d));
    brange = jedis.zrangeWithScores(bfoo, 0, 100);
    assertEquals(bexpected, brange);

  }

  @Test
  public void zrevrangeWithScores() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("b", 10d));
    expected.add(new Tuple("a", 2d));

    Set<Tuple> range = jedis.zrevrangeWithScores("foo", 0, 1);
    assertEquals(expected, range);

    expected.add(new Tuple("c", 0.1d));
    range = jedis.zrevrangeWithScores("foo", 0, 100);
    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bb, 10d));
    bexpected.add(new Tuple(ba, 2d));

    Set<Tuple> brange = jedis.zrevrangeWithScores(bfoo, 0, 1);
    assertEquals(bexpected, brange);

    bexpected.add(new Tuple(bc, 0.1d));
    brange = jedis.zrevrangeWithScores(bfoo, 0, 100);
    assertEquals(bexpected, brange);

  }

  @Test
  public void zcard() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    long size = jedis.zcard("foo");
    assertEquals(3, size);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    long bsize = jedis.zcard(bfoo);
    assertEquals(3, bsize);

  }

  @Test
  public void zscore() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Double score = jedis.zscore("foo", "b");
    assertEquals((Double) 10d, score);

    score = jedis.zscore("foo", "c");
    assertEquals((Double) 0.1d, score);

    score = jedis.zscore("foo", "s");
    assertNull(score);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Double bscore = jedis.zscore(bfoo, bb);
    assertEquals((Double) 10d, bscore);

    bscore = jedis.zscore(bfoo, bc);
    assertEquals((Double) 0.1d, bscore);

    bscore = jedis.zscore(bfoo, SafeEncoder.encode("s"));
    assertNull(bscore);

  }

  @Test
  public void zmscore() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    assertEquals(Arrays.asList(10d, 0.1d, null), jedis.zmscore("foo", "b", "c", "s"));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    assertEquals(Arrays.asList(10d, 0.1d, null),
      jedis.zmscore(bfoo, bb, bc, SafeEncoder.encode("s")));
  }

  @Test
  public void zpopmax() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "d");

    Tuple actual = jedis.zpopmax("foo");
    Tuple expected = new Tuple("b", 10d);
    assertEquals(expected, actual);

    actual = jedis.zpopmax("foo");
    expected = new Tuple("d", 2d);
    assertEquals(expected, actual);

    actual = jedis.zpopmax("foo");
    expected = new Tuple("a", 1d);
    assertEquals(expected, actual);

    actual = jedis.zpopmax("foo");
    expected = new Tuple("c", 0.1d);
    assertEquals(expected, actual);

    // Empty
    actual = jedis.zpopmax("foo");
    assertNull(actual);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    // First
    actual = jedis.zpopmax(bfoo);
    expected = new Tuple(bb, 10d);
    assertEquals(expected, actual);

    // Second
    actual = jedis.zpopmax(bfoo);
    expected = new Tuple(ba, 2d);
    assertEquals(expected, actual);

    // Third
    actual = jedis.zpopmax(bfoo);
    expected = new Tuple(bc, 0.1d);
    assertEquals(expected, actual);

    // Empty
    actual = jedis.zpopmax(bfoo);
    assertNull(actual);
  }

  @Test
  public void zpopmaxWithCount() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "d");
    jedis.zadd("foo", 0.03, "e");

    Set<Tuple> actual = jedis.zpopmax("foo", 2);
    assertEquals(2, actual.size());

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("b", 10d));
    expected.add(new Tuple("d", 2d));
    assertEquals(expected, actual);

    actual = jedis.zpopmax("foo", 3);
    assertEquals(3, actual.size());

    expected.clear();
    expected.add(new Tuple("a", 1d));
    expected.add(new Tuple("c", 0.1d));
    expected.add(new Tuple("e", 0.03d));
    assertEquals(expected, actual);

    // Empty
    actual = jedis.zpopmax("foo", 1);
    expected.clear();
    assertEquals(expected, actual);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    // First
    actual = jedis.zpopmax(bfoo, 1);
    expected.clear();
    expected.add(new Tuple(bb, 10d));
    assertEquals(expected, actual);

    // Second
    actual = jedis.zpopmax(bfoo, 1);
    expected.clear();
    expected.add(new Tuple(ba, 2d));
    assertEquals(expected, actual);

    // Last 2 (just 1, because 1 was overwritten)
    actual = jedis.zpopmax(bfoo, 1);
    expected.clear();
    expected.add(new Tuple(bc, 0.1d));
    assertEquals(expected, actual);

    // Empty
    actual = jedis.zpopmax(bfoo, 1);
    expected.clear();
    assertEquals(expected, actual);
  }

  @Test
  public void zpopmin() {

    jedis.zadd("foo", 1d, "a", ZAddParams.zAddParams().nx());
    jedis.zadd("foo", 10d, "b", ZAddParams.zAddParams().nx());
    jedis.zadd("foo", 0.1d, "c", ZAddParams.zAddParams().nx());
    jedis.zadd("foo", 2d, "a", ZAddParams.zAddParams().nx());

    Set<Tuple> range = jedis.zpopmin("foo", 2);

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("c", 0.1d));
    expected.add(new Tuple("a", 1d));

    assertEquals(expected, range);

    Tuple tuple = jedis.zpopmin("foo");
    assertEquals(new Tuple("b", 10d), tuple);

    // Binary

    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<Tuple> brange = jedis.zpopmin(bfoo, 2);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bc, 0.1d));
    bexpected.add(new Tuple(ba, 2d));

    assertEquals(bexpected, brange);

    tuple = jedis.zpopmin(bfoo);
    assertEquals(new Tuple(bb, 10d), tuple);
  }

  @Test
  public void zcount() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    long result = jedis.zcount("foo", 0.01d, 2.1d);

    assertEquals(2, result);

    result = jedis.zcount("foo", "(0.01", "+inf");

    assertEquals(3, result);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    long bresult = jedis.zcount(bfoo, 0.01d, 2.1d);

    assertEquals(2, bresult);

    bresult = jedis.zcount(bfoo, SafeEncoder.encode("(0.01"), SafeEncoder.encode("+inf"));

    assertEquals(3, bresult);
  }

  @Test
  public void zlexcount() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 1, "b");
    jedis.zadd("foo", 1, "c");
    jedis.zadd("foo", 1, "aa");

    long result = jedis.zlexcount("foo", "[aa", "(c");
    assertEquals(2, result);

    result = jedis.zlexcount("foo", "-", "+");
    assertEquals(4, result);

    result = jedis.zlexcount("foo", "-", "(c");
    assertEquals(3, result);

    result = jedis.zlexcount("foo", "[aa", "+");
    assertEquals(3, result);
  }

  @Test
  public void zlexcountBinary() {
    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 1, bc);
    jedis.zadd(bfoo, 1, bb);

    long result = jedis.zlexcount(bfoo, bInclusiveB, bExclusiveC);
    assertEquals(1, result);

    result = jedis.zlexcount(bfoo, bLexMinusInf, bLexPlusInf);
    assertEquals(3, result);
  }

  @Test
  public void zrangebyscore() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Set<String> range = jedis.zrangeByScore("foo", 0d, 2d);

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("c");
    expected.add("a");

    assertEquals(expected, range);

    range = jedis.zrangeByScore("foo", 0d, 2d, 0, 1);

    expected = new LinkedHashSet<String>();
    expected.add("c");

    assertEquals(expected, range);

    range = jedis.zrangeByScore("foo", 0d, 2d, 1, 1);
    Set<String> range2 = jedis.zrangeByScore("foo", "-inf", "(2");
    assertEquals(expected, range2);

    expected = new LinkedHashSet<String>();
    expected.add("a");

    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<byte[]> brange = jedis.zrangeByScore(bfoo, 0d, 2d);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bc);
    bexpected.add(ba);

    assertByteArraySetEquals(bexpected, brange);

    brange = jedis.zrangeByScore(bfoo, 0d, 2d, 0, 1);

    bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bc);

    assertByteArraySetEquals(bexpected, brange);

    brange = jedis.zrangeByScore(bfoo, 0d, 2d, 1, 1);
    Set<byte[]> brange2 = jedis.zrangeByScore(bfoo, SafeEncoder.encode("-inf"),
      SafeEncoder.encode("(2"));
    assertByteArraySetEquals(bexpected, brange2);

    bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(ba);

    assertByteArraySetEquals(bexpected, brange);

  }

  @Test
  public void zrevrangebyscore() {
    jedis.zadd("foo", 1.0d, "a");
    jedis.zadd("foo", 2.0d, "b");
    jedis.zadd("foo", 3.0d, "c");
    jedis.zadd("foo", 4.0d, "d");
    jedis.zadd("foo", 5.0d, "e");

    Set<String> range = jedis.zrevrangeByScore("foo", 3d, Double.NEGATIVE_INFINITY, 0, 1);
    Set<String> expected = new LinkedHashSet<String>();
    expected.add("c");

    assertEquals(expected, range);

    range = jedis.zrevrangeByScore("foo", 3.5d, Double.NEGATIVE_INFINITY, 0, 2);
    expected = new LinkedHashSet<String>();
    expected.add("c");
    expected.add("b");

    assertEquals(expected, range);

    range = jedis.zrevrangeByScore("foo", 3.5d, Double.NEGATIVE_INFINITY, 1, 1);
    expected = new LinkedHashSet<String>();
    expected.add("b");

    assertEquals(expected, range);

    range = jedis.zrevrangeByScore("foo", 4d, 2d);
    expected = new LinkedHashSet<String>();
    expected.add("d");
    expected.add("c");
    expected.add("b");

    assertEquals(expected, range);

    range = jedis.zrevrangeByScore("foo", "+inf", "(4");
    expected = new LinkedHashSet<String>();
    expected.add("e");

    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<byte[]> brange = jedis.zrevrangeByScore(bfoo, 2d, 0d);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bc);
    bexpected.add(ba);

    assertByteArraySetEquals(bexpected, brange);

    brange = jedis.zrevrangeByScore(bfoo, 2d, 0d, 0, 1);

    bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(ba);

    assertByteArraySetEquals(bexpected, brange);

    Set<byte[]> brange2 = jedis.zrevrangeByScore(bfoo, SafeEncoder.encode("+inf"),
      SafeEncoder.encode("(2"));

    bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bb);

    assertByteArraySetEquals(bexpected, brange2);

    brange = jedis.zrevrangeByScore(bfoo, 2d, 0d, 1, 1);
    bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bc);

    assertByteArraySetEquals(bexpected, brange);
  }

  @Test
  public void zrangebyscoreWithScores() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    Set<Tuple> range = jedis.zrangeByScoreWithScores("foo", 0d, 2d);

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("c", 0.1d));
    expected.add(new Tuple("a", 2d));

    assertEquals(expected, range);

    range = jedis.zrangeByScoreWithScores("foo", 0d, 2d, 0, 1);

    expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("c", 0.1d));

    assertEquals(expected, range);

    range = jedis.zrangeByScoreWithScores("foo", 0d, 2d, 1, 1);

    expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("a", 2d));

    assertEquals(expected, range);

    // Binary

    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<Tuple> brange = jedis.zrangeByScoreWithScores(bfoo, 0d, 2d);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bc, 0.1d));
    bexpected.add(new Tuple(ba, 2d));

    assertEquals(bexpected, brange);

    brange = jedis.zrangeByScoreWithScores(bfoo, 0d, 2d, 0, 1);

    bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bc, 0.1d));

    assertEquals(bexpected, brange);

    brange = jedis.zrangeByScoreWithScores(bfoo, 0d, 2d, 1, 1);

    bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(ba, 2d));

    assertEquals(bexpected, brange);

  }

  @Test
  public void zrevrangebyscoreWithScores() {
    jedis.zadd("foo", 1.0d, "a");
    jedis.zadd("foo", 2.0d, "b");
    jedis.zadd("foo", 3.0d, "c");
    jedis.zadd("foo", 4.0d, "d");
    jedis.zadd("foo", 5.0d, "e");

    Set<Tuple> range = jedis.zrevrangeByScoreWithScores("foo", 3d, Double.NEGATIVE_INFINITY, 0, 1);
    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("c", 3.0d));

    assertEquals(expected, range);

    range = jedis.zrevrangeByScoreWithScores("foo", 3.5d, Double.NEGATIVE_INFINITY, 0, 2);
    expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("c", 3.0d));
    expected.add(new Tuple("b", 2.0d));

    assertEquals(expected, range);

    range = jedis.zrevrangeByScoreWithScores("foo", 3.5d, Double.NEGATIVE_INFINITY, 1, 1);
    expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("b", 2.0d));

    assertEquals(expected, range);

    range = jedis.zrevrangeByScoreWithScores("foo", 4d, 2d);
    expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("d", 4.0d));
    expected.add(new Tuple("c", 3.0d));
    expected.add(new Tuple("b", 2.0d));

    assertEquals(expected, range);

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    Set<Tuple> brange = jedis.zrevrangeByScoreWithScores(bfoo, 2d, 0d);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bc, 0.1d));
    bexpected.add(new Tuple(ba, 2d));

    assertEquals(bexpected, brange);

    brange = jedis.zrevrangeByScoreWithScores(bfoo, 2d, 0d, 0, 1);

    bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(ba, 2d));

    assertEquals(bexpected, brange);

    brange = jedis.zrevrangeByScoreWithScores(bfoo, 2d, 0d, 1, 1);

    bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bc, 0.1d));

    assertEquals(bexpected, brange);
  }

  @Test
  public void zremrangeByRank() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    long result = jedis.zremrangeByRank("foo", 0, 0);

    assertEquals(1, result);

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("a");
    expected.add("b");

    assertEquals(expected, jedis.zrange("foo", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    long bresult = jedis.zremrangeByRank(bfoo, 0, 0);

    assertEquals(1, bresult);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(ba);
    bexpected.add(bb);

    assertByteArraySetEquals(bexpected, jedis.zrange(bfoo, 0, 100));

  }

  @Test
  public void zremrangeByScore() {
    jedis.zadd("foo", 1d, "a");
    jedis.zadd("foo", 10d, "b");
    jedis.zadd("foo", 0.1d, "c");
    jedis.zadd("foo", 2d, "a");

    long result = jedis.zremrangeByScore("foo", 0, 2);

    assertEquals(2, result);

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("b");

    assertEquals(expected, jedis.zrange("foo", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bfoo, 0.1d, bc);
    jedis.zadd(bfoo, 2d, ba);

    long bresult = jedis.zremrangeByScore(bfoo, 0, 2);

    assertEquals(2, bresult);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(bb);

    assertByteArraySetEquals(bexpected, jedis.zrange(bfoo, 0, 100));
  }

  @Test
  public void zremrangeByLex() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 1, "b");
    jedis.zadd("foo", 1, "c");
    jedis.zadd("foo", 1, "aa");

    long result = jedis.zremrangeByLex("foo", "[aa", "(c");

    assertEquals(2, result);

    Set<String> expected = new LinkedHashSet<String>();
    expected.add("a");
    expected.add("c");

    assertEquals(expected, jedis.zrangeByLex("foo", "-", "+"));
  }

  @Test
  public void zremrangeByLexBinary() {
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 1, bc);
    jedis.zadd(bfoo, 1, bb);

    long bresult = jedis.zremrangeByLex(bfoo, bInclusiveB, bExclusiveC);

    assertEquals(1, bresult);

    Set<byte[]> bexpected = new LinkedHashSet<byte[]>();
    bexpected.add(ba);
    bexpected.add(bc);

    assertByteArraySetEquals(bexpected, jedis.zrangeByLex(bfoo, bLexMinusInf, bLexPlusInf));
  }

  @Test
  public void zunion() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");
    jedis.zadd("bar", 2, "a");
    jedis.zadd("bar", 2, "b");

    ZParams params = new ZParams();
    params.weights(2, 2.5);
    params.aggregate(ZParams.Aggregate.SUM);
    Set<String> expected = new LinkedHashSet<>();
    expected.add("a");
    expected.add("b");
    assertEquals(expected, jedis.zunion(params, "foo", "bar"));

    Set<Tuple> expectedTuple = new LinkedHashSet<>();
    expectedTuple.add(new Tuple("b", new Double(9)));
    expectedTuple.add(new Tuple("a", new Double(7)));
    assertEquals(expectedTuple, jedis.zunionWithScores(params, "foo", "bar"));

    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 2, bb);
    jedis.zadd(bbar, 2, ba);
    jedis.zadd(bbar, 2, bb);

    ZParams bparams = new ZParams();
    bparams.weights(2, 2.5);
    bparams.aggregate(ZParams.Aggregate.SUM);
    Set<byte[]> bexpected = new LinkedHashSet<>();
    bexpected.add(bb);
    bexpected.add(ba);
    assertByteArraySetEquals(bexpected, jedis.zunion(params, bfoo, bbar));

    Set<Tuple> bexpectedTuple = new LinkedHashSet<>();
    bexpectedTuple.add(new Tuple(bb, new Double(9)));
    bexpectedTuple.add(new Tuple(ba, new Double(7)));
    assertEquals(bexpectedTuple, jedis.zunionWithScores(bparams, bfoo, bbar));
  }

  @Test
  public void zunionstore() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");
    jedis.zadd("bar", 2, "a");
    jedis.zadd("bar", 2, "b");

    long result = jedis.zunionstore("dst", "foo", "bar");

    assertEquals(2, result);

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("b", new Double(4)));
    expected.add(new Tuple("a", new Double(3)));

    assertEquals(expected, jedis.zrangeWithScores("dst", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 2, bb);
    jedis.zadd(bbar, 2, ba);
    jedis.zadd(bbar, 2, bb);

    long bresult = jedis.zunionstore(SafeEncoder.encode("dst"), bfoo, bbar);

    assertEquals(2, bresult);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bb, new Double(4)));
    bexpected.add(new Tuple(ba, new Double(3)));

    assertEquals(bexpected, jedis.zrangeWithScores(SafeEncoder.encode("dst"), 0, 100));
  }

  @Test
  public void zunionstoreParams() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");
    jedis.zadd("bar", 2, "a");
    jedis.zadd("bar", 2, "b");

    ZParams params = new ZParams();
    params.weights(2, 2.5);
    params.aggregate(ZParams.Aggregate.SUM);
    long result = jedis.zunionstore("dst", params, "foo", "bar");

    assertEquals(2, result);

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("b", new Double(9)));
    expected.add(new Tuple("a", new Double(7)));

    assertEquals(expected, jedis.zrangeWithScores("dst", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 2, bb);
    jedis.zadd(bbar, 2, ba);
    jedis.zadd(bbar, 2, bb);

    ZParams bparams = new ZParams();
    bparams.weights(2, 2.5);
    bparams.aggregate(ZParams.Aggregate.SUM);
    long bresult = jedis.zunionstore(SafeEncoder.encode("dst"), bparams, bfoo, bbar);

    assertEquals(2, bresult);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(bb, new Double(9)));
    bexpected.add(new Tuple(ba, new Double(7)));

    assertEquals(bexpected, jedis.zrangeWithScores(SafeEncoder.encode("dst"), 0, 100));
  }

  @Test
  public void zinter() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");
    jedis.zadd("bar", 2, "a");

    ZParams params = new ZParams();
    params.weights(2, 2.5);
    params.aggregate(ZParams.Aggregate.SUM);
    assertEquals(Collections.singleton("a"), jedis.zinter(params, "foo", "bar"));

    assertEquals(Collections.singleton(new Tuple("a", new Double(7))),
      jedis.zinterWithScores(params, "foo", "bar"));

    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 2, bb);
    jedis.zadd(bbar, 2, ba);

    ZParams bparams = new ZParams();
    bparams.weights(2, 2.5);
    bparams.aggregate(ZParams.Aggregate.SUM);
    assertByteArraySetEquals(Collections.singleton(ba), jedis.zinter(params, bfoo, bbar));

    assertEquals(Collections.singleton(new Tuple(ba, new Double(7))),
      jedis.zinterWithScores(bparams, bfoo, bbar));
  }

  @Test
  public void zinterstore() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");
    jedis.zadd("bar", 2, "a");

    long result = jedis.zinterstore("dst", "foo", "bar");

    assertEquals(1, result);

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("a", new Double(3)));

    assertEquals(expected, jedis.zrangeWithScores("dst", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 2, bb);
    jedis.zadd(bbar, 2, ba);

    long bresult = jedis.zinterstore(SafeEncoder.encode("dst"), bfoo, bbar);

    assertEquals(1, bresult);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(ba, new Double(3)));

    assertEquals(bexpected, jedis.zrangeWithScores(SafeEncoder.encode("dst"), 0, 100));
  }

  @Test
  public void zintertoreParams() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");
    jedis.zadd("bar", 2, "a");

    ZParams params = new ZParams();
    params.weights(2, 2.5);
    params.aggregate(ZParams.Aggregate.SUM);
    long result = jedis.zinterstore("dst", params, "foo", "bar");

    assertEquals(1, result);

    Set<Tuple> expected = new LinkedHashSet<Tuple>();
    expected.add(new Tuple("a", new Double(7)));

    assertEquals(expected, jedis.zrangeWithScores("dst", 0, 100));

    // Binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 2, bb);
    jedis.zadd(bbar, 2, ba);

    ZParams bparams = new ZParams();
    bparams.weights(2, 2.5);
    bparams.aggregate(ZParams.Aggregate.SUM);
    long bresult = jedis.zinterstore(SafeEncoder.encode("dst"), bparams, bfoo, bbar);

    assertEquals(1, bresult);

    Set<Tuple> bexpected = new LinkedHashSet<Tuple>();
    bexpected.add(new Tuple(ba, new Double(7)));

    assertEquals(bexpected, jedis.zrangeWithScores(SafeEncoder.encode("dst"), 0, 100));
  }

  @Test
  public void zscan() {
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 2, "b");

    ScanResult<Tuple> result = jedis.zscan("foo", SCAN_POINTER_START);

    assertEquals(SCAN_POINTER_START, result.getCursor());
    assertFalse(result.getResult().isEmpty());

    // binary
    jedis.zadd(bfoo, 1, ba);
    jedis.zadd(bfoo, 1, bb);

    ScanResult<Tuple> bResult = jedis.zscan(bfoo, SCAN_POINTER_START_BINARY);

    assertArrayEquals(SCAN_POINTER_START_BINARY, bResult.getCursorAsBytes());
    assertFalse(bResult.getResult().isEmpty());
  }

  @Test
  public void zscanMatch() {
    ScanParams params = new ScanParams();
    params.match("a*");

    jedis.zadd("foo", 2, "b");
    jedis.zadd("foo", 1, "a");
    jedis.zadd("foo", 11, "aa");
    ScanResult<Tuple> result = jedis.zscan("foo", SCAN_POINTER_START, params);

    assertEquals(SCAN_POINTER_START, result.getCursor());
    assertFalse(result.getResult().isEmpty());

    // binary
    params = new ScanParams();
    params.match(bbarstar);

    jedis.zadd(bfoo, 2, bbar1);
    jedis.zadd(bfoo, 1, bbar2);
    jedis.zadd(bfoo, 11, bbar3);
    ScanResult<Tuple> bResult = jedis.zscan(bfoo, SCAN_POINTER_START_BINARY, params);

    assertArrayEquals(SCAN_POINTER_START_BINARY, bResult.getCursorAsBytes());
    assertFalse(bResult.getResult().isEmpty());

  }

  @Test
  public void zscanCount() {
    ScanParams params = new ScanParams();
    params.count(2);

    jedis.zadd("foo", 1, "a1");
    jedis.zadd("foo", 2, "a2");
    jedis.zadd("foo", 3, "a3");
    jedis.zadd("foo", 4, "a4");
    jedis.zadd("foo", 5, "a5");

    ScanResult<Tuple> result = jedis.zscan("foo", SCAN_POINTER_START, params);

    assertFalse(result.getResult().isEmpty());

    // binary
    params = new ScanParams();
    params.count(2);

    jedis.zadd(bfoo, 2, bbar1);
    jedis.zadd(bfoo, 1, bbar2);
    jedis.zadd(bfoo, 11, bbar3);

    ScanResult<Tuple> bResult = jedis.zscan(bfoo, SCAN_POINTER_START_BINARY, params);

    assertFalse(bResult.getResult().isEmpty());
  }

  @Test
  public void infinity() {
    jedis.zadd("key", Double.POSITIVE_INFINITY, "pos");
    assertEquals(Double.POSITIVE_INFINITY, jedis.zscore("key", "pos"), 0d);
    jedis.zadd("key", Double.NEGATIVE_INFINITY, "neg");
    assertEquals(Double.NEGATIVE_INFINITY, jedis.zscore("key", "neg"), 0d);
    jedis.zadd("key", 0d, "zero");

    Set<Tuple> set = jedis.zrangeWithScores("key", 0, -1);
    Iterator<Tuple> itr = set.iterator();
    assertEquals(Double.NEGATIVE_INFINITY, itr.next().getScore(), 0d);
    assertEquals(0d, itr.next().getScore(), 0d);
    assertEquals(Double.POSITIVE_INFINITY, itr.next().getScore(), 0d);
  }

  @Test
  public void bzpopmax() {
    jedis.zadd("foo", 1d, "a", ZAddParams.zAddParams().nx());
    jedis.zadd("foo", 10d, "b", ZAddParams.zAddParams().nx());
    jedis.zadd("bar", 0.1d, "c", ZAddParams.zAddParams().nx());
    assertEquals(new KeyedZSetElement("foo", "b", 10d), jedis.bzpopmax(0, "foo", "bar"));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bbar, 0.1d, bc);
    List<byte[]> actual = jedis.bzpopmax(0, bfoo, bbar);
    assertEquals(3, actual.size());
    assertArrayEquals(bfoo, actual.get(0));
    assertArrayEquals(bb, actual.get(1));
    assertEquals(10d, BuilderFactory.DOUBLE.build(actual.get(2)), 1e-10);
  }

  @Test
  public void bzpopmin() {
    jedis.zadd("foo", 1d, "a", ZAddParams.zAddParams().nx());
    jedis.zadd("foo", 10d, "b", ZAddParams.zAddParams().nx());
    jedis.zadd("bar", 0.1d, "c", ZAddParams.zAddParams().nx());
    assertEquals(new KeyedZSetElement("bar", "c", 0.1d), jedis.bzpopmin(0, "bar", "foo"));

    // Binary
    jedis.zadd(bfoo, 1d, ba);
    jedis.zadd(bfoo, 10d, bb);
    jedis.zadd(bbar, 0.1d, bc);
    List<byte[]> actual = jedis.bzpopmin(0, bbar, bfoo);
    assertEquals(3, actual.size());
    assertArrayEquals(bbar, actual.get(0));
    assertArrayEquals(bc, actual.get(1));
    assertEquals(0.1d, BuilderFactory.DOUBLE.build(actual.get(2)), 1e-10);
  }

  @Test
  public void zdiff() {
    jedis.zadd("foo", 1.0, "a");
    jedis.zadd("foo", 2.0, "b");
    jedis.zadd("bar", 1.0, "a");

    assertEquals(0, jedis.zdiff("bar1", "bar2").size());
    assertEquals(Collections.singleton("b"), jedis.zdiff("foo", "bar"));
    assertEquals(Collections.singleton(new Tuple("b", 2.0d)), jedis.zdiffWithScores("foo", "bar"));

    // binary

    jedis.zadd(bfoo, 1.0, ba);
    jedis.zadd(bfoo, 2.0, bb);
    jedis.zadd(bbar, 1.0, ba);

    assertEquals(0, jedis.zdiff(bbar1, bbar2).size());
    Set<byte[]> bactual = jedis.zdiff(bfoo, bbar);
    assertEquals(1, bactual.size());
    assertArrayEquals(bb, bactual.iterator().next());
    assertEquals(Collections.singleton(new Tuple(bb, 2.0d)), jedis.zdiffWithScores(bfoo, bbar));
  }

  @Test
  public void zdiffStore() {
    jedis.zadd("foo", 1.0, "a");
    jedis.zadd("foo", 2.0, "b");
    jedis.zadd("bar", 1.0, "a");

    assertEquals(0, jedis.zdiffStore("bar3", "bar1", "bar2").longValue());
    assertEquals(1, jedis.zdiffStore("bar3", "foo", "bar").longValue());
    assertEquals(Collections.singleton("b"), jedis.zrange("bar3", 0, -1));

    // binary

    jedis.zadd(bfoo, 1.0, ba);
    jedis.zadd(bfoo, 2.0, bb);
    jedis.zadd(bbar, 1.0, ba);

    assertEquals(0, jedis.zdiffStore(bbar3, bbar1, bbar2).longValue());
    assertEquals(1, jedis.zdiffStore(bbar3, bfoo, bbar).longValue());
    Set<byte[]> bactual = jedis.zrange(bbar3, 0, -1);
    assertArrayEquals(bb, bactual.iterator().next());
  }

  @Test
  public void zrandmember() {
    assertNull(jedis.zrandmember("foo"));
    assertEquals(Collections.emptySet(), jedis.zrandmember("foo", 1));
    assertEquals(Collections.emptySet(), jedis.zrandmemberWithScores("foo", 1));

    Map<String, Double> hash = new HashMap<>();
    hash.put("bar1", 1d);
    hash.put("bar2", 10d);
    hash.put("bar3", 0.1d);
    jedis.zadd("foo", hash);

    assertTrue(hash.containsKey(jedis.zrandmember("foo")));
    assertEquals(2, jedis.zrandmember("foo", 2).size());

    Set<Tuple> actual = jedis.zrandmemberWithScores("foo", 2);
    assertNotNull(actual);
    assertEquals(2, actual.size());
    Tuple tuple = actual.iterator().next();
    assertEquals(hash.get(tuple.getElement()), Double.valueOf(tuple.getScore()));

    // Binary
    assertNull(jedis.zrandmember(bfoo));
    assertEquals(Collections.emptySet(), jedis.zrandmember(bfoo, 1));
    assertEquals(Collections.emptySet(), jedis.zrandmemberWithScores(bfoo, 1));

    Map<byte[], Double> bhash = new HashMap<>();
    bhash.put(bbar1, 1d);
    bhash.put(bbar2, 10d);
    bhash.put(bbar3, 0.1d);
    jedis.zadd(bfoo, bhash);

    assertCollectionContains(bhash.keySet(), jedis.zrandmember(bfoo));
    assertEquals(2, jedis.zrandmember(bfoo, 2).size());

    Set<Tuple> bactual = jedis.zrandmemberWithScores(bfoo, 2);
    assertNotNull(actual);
    assertEquals(2, actual.size());
    tuple = bactual.iterator().next();
    assertEquals(getScoreFromByteMap(bhash, tuple.getBinaryElement()), Double.valueOf(tuple.getScore()));
  }

  private Double getScoreFromByteMap(Map<byte[], Double> bhash, byte[] key) {
    for (Map.Entry<byte[], Double> en : bhash.entrySet()) {
      if (Arrays.equals(en.getKey(), key)) {
        return en.getValue();
      }
    }
    return null;
  }
}
